const express = require("express");
const router = express.Router();

// Allow GET for browser testing
router.get("/", (req, res) => {
  res.json({
    hint: "Think about which SQL keyword retrieves data from a table."
  });
});

// Keep POST for frontend usage
router.post("/", (req, res) => {
  res.json({
    hint: "Think about which SQL keyword retrieves data from a table."
  });
});

module.exports = router;
