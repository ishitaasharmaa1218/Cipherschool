const express = require("express");
const router = express.Router();

router.post("/", (req, res) => {
  const { query } = req.body;

  if (!query || !query.toLowerCase().startsWith("select")) {
    return res.status(400).json({
      error: "Only SELECT queries are allowed"
    });
  }

  // Dummy data (later PostgreSQL)
  res.json({
    rows: [
      { id: 1, name: "Amit", salary: 40000 },
      { id: 2, name: "Neha", salary: 55000 }
    ]
  });
});

module.exports = router;
