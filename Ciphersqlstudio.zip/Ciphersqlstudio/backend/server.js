const express = require("express");
const cors = require("cors");

const executeRoute = require("./routes/executeQuery");
const hintRoute = require("./routes/hint");

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/execute", executeRoute);
app.use("/api/hint", hintRoute);

app.listen(5000, () => {
  console.log("Backend running on port 5000");
});
