import { useParams } from "react-router-dom";
import { useState } from "react";
import SQLEditor from "../components/SQLEditor";

function AssignmentAttempt() {
  const { id } = useParams();

  // STATES
  const [query, setQuery] = useState("SELECT * FROM employees;");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [hint, setHint] = useState("");

  // DUMMY ASSIGNMENT DATA
  const assignment = {
    question: "Fetch all records from the employees table.",
    tableName: "employees",
    columns: ["id", "name", "salary"],
    rows: [
      { id: 1, name: "Amit", salary: 40000 },
      { id: 2, name: "Neha", salary: 55000 },
      { id: 3, name: "Rohit", salary: 60000 }
    ]
  };

  // EXECUTE QUERY (DUMMY LOGIC)
  const runQuery = () => {
    if (query.toLowerCase().includes("select")) {
      setResult(assignment.rows);
      setError("");
    } else {
      setError("Only SELECT queries are allowed.");
      setResult(null);
    }
  };

  // GET HINT (DUMMY LLM LOGIC)
  const getHint = async () => {
  try {
    const response = await fetch("http://localhost:5000/api/hint", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        question: assignment.question,
        userQuery: query
      })
    });

    const data = await response.json();
    setHint(data.hint);
  } catch (error) {
    setHint("Failed to fetch hint from server");
  }
};


  return (
    <div>
      <h1>Assignment Attempt</h1>
      <p>Assignment ID: {id}</p>

      {/* QUESTION */}
      <section>
        <h2>Question</h2>
        <p>{assignment.question}</p>
      </section>

      {/* SAMPLE DATA */}
      <section>
        <h2>Sample Data: {assignment.tableName}</h2>
        <table border="1" cellPadding="8">
          <thead>
            <tr>
              {assignment.columns.map((col) => (
                <th key={col}>{col}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {assignment.rows.map((row, index) => (
              <tr key={index}>
                {assignment.columns.map((col) => (
                  <td key={col}>{row[col]}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {/* SQL EDITOR */}
      <section>
        <h2>Write Your SQL Query</h2>
        <SQLEditor query={query} setQuery={setQuery} />
      </section>

      {/* BUTTONS */}
      <div style={{ marginTop: "15px" }}>
        <button onClick={runQuery}>Execute Query</button>
        <button onClick={getHint} style={{ marginLeft: "10px" }}>
          Get Hint
        </button>
      </div>

      {/* ERROR */}
      {error && <p style={{ color: "red" }}>{error}</p>}

      {/* HINT */}
      {hint && <p style={{ color: "blue" }}>{hint}</p>}

      {/* RESULT */}
      {result && (
        <section>
          <h2>Query Result</h2>
          <table border="1" cellPadding="8">
            <thead>
              <tr>
                {assignment.columns.map((col) => (
                  <th key={col}>{col}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {result.map((row, index) => (
                <tr key={index}>
                  {assignment.columns.map((col) => (
                    <td key={col}>{row[col]}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}
    </div>
  );
}

export default AssignmentAttempt;
