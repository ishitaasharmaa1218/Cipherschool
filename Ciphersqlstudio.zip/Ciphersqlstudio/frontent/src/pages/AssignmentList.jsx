import AssignmentCard from "../components/AssignmentCard";

function AssignmentList() {
  const assignments = [
    {
      id: 1,
      title: "Select All Employees",
      difficulty: "Easy",
      description: "Fetch all records from the employees table."
    },
    {
      id: 2,
      title: "Employees with Salary > 50000",
      difficulty: "Medium",
      description: "Find employees earning more than 50,000."
    }
  ];

  return (
    <div>
      <h1>SQL Assignments</h1>
      {assignments.map((item) => (
        <AssignmentCard
          key={item.id}
    id={item.id}
    title={item.title}
    difficulty={item.difficulty}
    description={item.description}
        />
      ))}
    </div>
  );
}

export default AssignmentList;
