import { useNavigate } from "react-router-dom";

function AssignmentCard({ id, title, difficulty, description }) {
  const navigate = useNavigate();

  return (
    <div
      className="assignment-card"
      onClick={() => navigate(`/assignment/${id}`)}
      style={{ cursor: "pointer" }}
    >
      <h2 className="assignment-card__title">{title}</h2>
      <span className="assignment-card__difficulty">{difficulty}</span>
      <p className="assignment-card__description">{description}</p>
    </div>
  );
}

export default AssignmentCard;
