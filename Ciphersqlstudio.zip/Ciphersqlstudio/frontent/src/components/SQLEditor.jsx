import Editor from "@monaco-editor/react";

function SQLEditor({ query, setQuery }) {
  return (
    <div>
      <Editor
        height="200px"
        defaultLanguage="sql"
        value={query}
        onChange={(value) => setQuery(value)}
        options={{
          minimap: { enabled: false },
          fontSize: 14,
        }}
      />
    </div>
  );
}

export default SQLEditor;
